nama = input ("masukkan nama kamu: ")
nama_panggilan = input ("masukkan nama panggilan kamu: ")
print ("nama saya, " + nama)
print ("kamu bisa panggil saya", nama_panggilan)